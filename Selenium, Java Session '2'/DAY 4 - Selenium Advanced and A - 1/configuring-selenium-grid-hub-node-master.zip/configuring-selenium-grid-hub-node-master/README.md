# maven-cucumber-jvm-selenium-grid-java-hub-node
maven-cucumber-jvm-selenium-grid-java-hub-node

1. Download the project
2. Create a folder in the following location - 'C:\Selenium'
3. Transfer contents of the project into this folder location
4. Run the selenium hub bat file 
5. Run the selenium chrome node bat file and firefox node bat file
Your Selenium hub node configuration is ready!
6. Double click the 'Open-Grid-Console-In-Browser.bat' file to see the grid console in browser
