package SupportLibraries;


public class PropertyFIlePath {
     public void main(String as[])
     {
     }
     public String show() {
         return "src//PropertyFile//SeleniumObjects.properties";
  }
     
    //Dummy code
     public String dummy() {
         return "src//PropertyFile//dummy.properties";
  }
     
 
    
}